---
name: adu-pdf-extraction
description: "This skill extracts construction PDF plan binders into agent-consumable formats. It should be used when a contractor or homeowner provides a PDF binder of construction plans (site plans, floor plans, structural drawings, Title 24 reports) that needs to be parsed for permit review, corrections response, or plan check analysis. Produces three outputs: page PNGs for vision analysis, a structured JSON manifest for routing, and optional text extraction for keyword search."
---

# Construction PDF Binder Extraction

## Purpose

Extract multi-page construction plan PDF binders into a three-layer structure
that enables an AI agent to efficiently navigate, reference, and respond to
specific pages and drawing zones within the plans.

Construction PDFs are uniquely challenging because:
- Single PDF pages often contain multiple sub-pages composited together
- Text is rendered by CAD software in non-extractable ways
- Watermarks (e.g., "Study Set - Not For Construction") inject diagonal
  characters that pollute text extraction
- Drawing content (dimensions, callouts, symbols) carries critical meaning
  that only vision can interpret
- Title 24 energy reports are often rasterized images, not selectable text

## When to Use

Invoke this skill when:
- A PDF binder of construction plans is provided (typically 10-30+ pages)
- Plan check corrections need to reference specific sheets and locations
- A permit checklist needs to be generated from submitted plans
- Any construction document needs to be made queryable by an AI agent

## Extraction Process

### Step 1: Prepare Output Directory

Create the output directory structure:

```
{output-dir}/
├── pages-png/           # One PNG per PDF page (primary content source)
├── pages-tesseract/     # Tesseract OCR text per page (supplementary)
└── binder-manifest.json # Structured page index (the key routing artifact)
```

### Step 2: Extract Page PNGs (Primary Content Source)

Run `scripts/extract-pages.sh` to split the PDF into individual page PNGs:

```bash
scripts/extract-pages.sh INPUT.pdf OUTPUT_DIR
```

This uses `pdftoppm` at 200 DPI. Each page becomes `page-01.png`,
`page-02.png`, etc. These PNGs are the **primary content source** — vision
analysis of these images is far more reliable than text extraction for
construction documents.

If `pdftoppm` is not available, fall back to ImageMagick:
```bash
magick -density 200 input.pdf -quality 90 output-dir/pages-png/page-%02d.png
```

### Step 3: OCR Text via Tesseract (Supplementary)

Run `scripts/extract-text.sh` to OCR each page PNG with Tesseract:

```bash
scripts/extract-text.sh INPUT.pdf OUTPUT_DIR
```

This runs Tesseract OCR on the page PNGs (extracts them first if needed).
Output goes to `output-dir/pages-tesseract/page-01.txt`, etc.

**Why Tesseract over pdftotext:** Testing on real construction PDFs showed
Tesseract produces dramatically better results than pdftotext or pdfplumber:

| Method | Drawing Pages | Structural Notes | Title 24 (rasterized) |
|--------|--------------|-----------------|----------------------|
| pdftotext | Garbage (blank lines, watermark chars) | Usable | Empty |
| pdfplumber | Reversed text from rotated title blocks | Good | 367 chars |
| **Tesseract** | **Fair (some interleaving)** | **Good** | **9.8K chars — full data** |

Tesseract wins because it reads the rendered pixels, not the PDF text layer.
It handles rasterized content (Title 24 CF1R), reads through watermarks, and
produces compact output without blank-line padding.

**Do NOT use pdftotext or pdfplumber for construction PDFs.** They fail on:
- CAD-rendered text (most architectural/structural sheets)
- Rotated text in title blocks (produces reversed strings like `*TEEHS REVOC*`)
- Rasterized pages (Title 24 reports — zero output)
- Watermarked pages (diagonal chars scattered across blank lines)

Tesseract output is supplementary to vision — use it for keyword search and
quick lookups. Always prefer Claude vision on the PNGs for structured content
extraction and spatial understanding.

### Step 4: Build the Page Manifest via Vision (The Key Artifact)

The manifest is what makes everything else useful. It enables an agent to
route to the correct page(s) without loading all pages into context.

**To build the manifest, read each page PNG using vision** and produce a JSON
file following the schema in `references/manifest-schema.md`.

For each page, visually inspect the PNG and identify:

1. **Sheet ID and title** — from the title block (usually bottom-right corner)
2. **Category** — general, architectural, structural, energy, code_compliance,
   mechanical, plumbing, electrical
3. **What's on the page** — key content items, described specifically enough
   to match correction letter items
4. **Topics** — keyword tags for routing (e.g., "shearwall", "setbacks",
   "Title 24")
5. **Drawing zones** — spatial map of where things are on the page
   (top-left, center, bottom-right, etc.)
6. **Content flags** — `text_extractable` (does Tesseract OCR produce useful
   output?) and `image_critical` (must vision be used for full understanding?)

#### Vision Extraction Strategy

Process pages in batches. For each page PNG:

1. Read the image using the Read tool (Claude's multimodal vision)
2. Identify the title block first (bottom-right or right-edge)
3. Scan the full page for all drawings, tables, notes, and schedules
4. Map each content element to a spatial zone
5. Extract key data points that corrections or checklists commonly reference

For pages with dense content (like floor plans or structural details), zoom
into specific regions if needed for accurate extraction.

#### Reading Title Blocks

Construction plan title blocks follow consistent conventions:

- **Location**: Bottom-right corner or right edge of each sheet
- **Contains**: Sheet number (e.g., "A2", "S1"), sheet title,
  designer/engineer name, project info, revision dates
- **Sheet numbering convention**:
  - `CS` = Cover Sheet
  - `A` prefix = Architectural (site plans, floor plans, elevations)
  - `S` prefix = Structural (foundation, framing, details)
  - `SN` prefix = Structural Notes
  - `T` prefix = Title 24 / Energy
  - `AIA` prefix = CalGreen/code checklists
  - `M` prefix = Mechanical
  - `P` prefix = Plumbing
  - `E` prefix = Electrical

#### Drawing Zone Mapping

To enable precise references like "Sheet S2, detail 8, mid-left quadrant":

- Divide each page into a grid (top/middle/bottom x left/center/right)
- For detail sheets with numbered detail bubbles, map bubble numbers to zones
- For plans, note which drawing is in which half (e.g., "left-half:
  foundation plan, right-half: framing plan")

### Step 5: Validate Outputs

After extraction, verify:
- PNG count matches PDF page count
- Manifest JSON is valid and has entries for every page
- Every `sheet_id` in the manifest matches what's visible in the PNG title block
- Text files exist for all pages (even if sparse)

## Using Extraction Results

### For Corrections Response (Flow 2)

When interpreting a corrections letter against extracted plans:

1. Parse each correction item for keywords
2. Match keywords against manifest `topics` and `key_content` arrays
3. Load only the matched page PNGs into context (vision)
4. Reference corrections by sheet ID and drawing zone:
   *"See Sheet S2 (page 11), Shearwall Schedule in the mid-left quadrant"*

### For Permit Checklist (Flow 1)

When generating a permit checklist from extracted plans:

1. Load the cover sheet manifest entry for project overview
2. Walk each category (architectural, structural, energy) loading relevant pages
3. Extract key data points from PNGs via vision
4. Cross-reference against ADU regulatory skill requirements

## Typical Sheet Types in ADU Binders

For reference, a typical California ADU plan binder contains:

| Category | Typical Sheets | What to Look For |
|----------|---------------|-----------------|
| General | CS (Cover) | Scope of work, sheet index, lot coverage, general notes |
| Code | AIA.1, AIA.2 | CalGreen checklists, compliance checkboxes |
| Architectural | A1-A4 | Site plan, floor plan, elevations, sections, schedules |
| Structural | SN1-SN2, S1-S3 | Notes, foundation, framing, details, shearwall schedules |
| Energy | T-1 through T-3 | CF1R compliance, HVAC specs, mandatory requirements |
| MEP | M1, P1, E1 | Mechanical, plumbing, electrical (not always separate sheets) |

## Resources

### scripts/
- `extract-pages.sh` — Split PDF into per-page PNGs using pdftoppm (200 DPI)
- `extract-text.sh` — OCR text from page PNGs using Tesseract (supplementary)

### references/
- `manifest-schema.md` — JSON schema and field descriptions for binder-manifest.json
- `extraction-findings.md` — Lessons learned from testing on real construction PDFs
