# Extraction Findings — Lessons from Real Construction PDFs

Documented from testing on a 15-page ADU plan binder (1232 N. Jefferson St.,
Placentia, CA — New Detached ADU, 600 sq ft).

## Key Finding: Tesseract + Vision Hybrid Wins

Four text extraction methods were tested head-to-head on the same pages.
Vision (Claude reading PNGs) produces the best structured output, while
Tesseract OCR is the best automated bulk extraction method.

### Head-to-Head: Page 6 (Floor Plan w/ Electrical — hardest page type)

| Method | Bytes | Content Quality |
|--------|-------|-----------------|
| pdftotext | 10.7K | Garbage — headers + blank lines + watermark chars (~90% waste) |
| pdfplumber | 1.7K | Bad — reversed text from rotated title blocks (`*TEEHS REVOC*`) |
| **Tesseract OCR** | **11.6K** | **Fair — real data, some column interleaving** |
| **Claude Vision** | **9.4K** | **Best — structured markdown, real tables, zone-organized** |

### Head-to-Head: Page 13 (Title 24 CF1R — rasterized content)

| Method | Result |
|--------|--------|
| pdftotext | 32 lines — all watermark noise, zero data |
| pdfplumber | 367 chars — reversed text fragments |
| **Tesseract OCR** | **9.8K chars — full CF1R data, EUI values, PV requirements** |
| Claude Vision | Also reads it well via image |

### Why Each Method Fails or Succeeds

**pdftotext** — Reads the PDF text layer directly. Fails because:
- CAD software stores text as individual character glyphs, not logical runs
- Diagonal watermarks scatter characters across dozens of blank output lines
- Rasterized pages (Title 24) have no text layer at all
- Produces massive token waste from blank line padding

**pdfplumber** — Python library, reads PDF text layer with better layout
awareness. Slightly better at tables but still fails because:
- Rotated text in title blocks produces reversed strings
- Same rasterized-content blindness as pdftotext
- Still can't handle CAD-rendered text on drawing sheets

**Tesseract OCR** — Reads the rendered pixels from page PNGs. Wins because:
- Reads rasterized content (Title 24 CF1R reports)
- Handles CAD-rendered text that PDF text extraction cannot
- Reads through watermarks (sees the actual content underneath)
- Produces compact output without blank-line padding
- Fast: ~75 seconds for all 15 pages

**Claude Vision** — Reads page PNGs via multimodal vision. Best quality:
- Structured markdown output with headers and tables
- Spatial understanding (organizes by drawing zones)
- Interprets symbols, dimensions, and detail callouts
- Reads through watermarks naturally
- But: ~110 seconds per page, higher token cost

### Recommended Approach: Tesseract + Vision Hybrid

1. **Tesseract** for bulk text extraction (all pages, automated, fast)
2. **Claude Vision** for manifest building (structured page index)
3. **Claude Vision** for targeted deep extraction (specific pages as needed)
4. **Skip pdftotext and pdfplumber** — they are worse on every page type

## Performance Characteristics

Tested on a 15-page ADU binder (14.2 MB PDF):

| Operation | Time | Output Size |
|-----------|------|-------------|
| PNG extraction (pdftoppm, 200 DPI) | ~85s | 48 MB (15 PNGs) |
| Tesseract OCR (all 15 pages) | ~75s | ~120 KB (15 txt files) |
| Manifest creation (vision + write) | ~170s | 28 KB (1 JSON) |
| Vision extraction (1 page, deep) | ~110s | ~9 KB structured markdown |
| **Total (PNG + OCR + manifest)** | **~5.5 min** | **~48 MB** |

PNG and Tesseract OCR can run in parallel. Manifest creation requires the
PNGs to already exist (for vision analysis).

## Watermark Detection

Common watermarks in construction PDFs:
- "Study Set - Not For Construction"
- "Prepped for City Submittal"
- "PRELIMINARY - NOT FOR CONSTRUCTION"
- "FOR REVIEW ONLY"
- "DRAFT"

These appear as diagonal text overlays. In pdftotext/pdfplumber output, they
produce scattered single characters across blank lines. Tesseract handles
them much better because it reads the full rendered page and can distinguish
primary text from overlay text.

## Manifest as Routing Layer

The manifest JSON is the key innovation. Without it, an agent must either:
- Load all 15 pages into context (~22,500 vision tokens) for every query, or
- Guess which pages to look at

With the manifest, the agent can:
1. Search `topics` and `key_content` arrays for keyword matches
2. Load only 1-3 relevant page PNGs
3. Reference specific `drawing_zones` in its response

Example routing: correction says "provide shearwall nailing schedule"
-> manifest search finds "nailing schedule" in SN2 topics and "shearwall
schedule" in S2 topics -> agent loads pages 9 and 11 PNGs only.

## Vision Extraction Quality (Page 6 Deep Dive)

When Claude Vision extracted page 6 (Sheet A2 — Floor Plan), it produced:
- Window Schedule: 3 entries with sizes, glazing, materials, types
- Door Schedule: 5 entries with frames, materials, lock types
- 14+ Kitchen Electrical Notes with NEC code references
- 7 Smoke/CO Alarm requirements with CRC R314/R315 refs
- Plumbing Fixture flow rates (1.8 GPM kitchen, 1.2 GPM lavatory, 1.28 GPF WC)
- Bedroom egress standards (5.7 sq ft, 20" width, 24" height, 44" max sill)
- Confidence annotations flagging watermark-obscured sections

Limitations observed:
- Dense fine-print notes partially obscured by watermark
- Small in-drawing dimensions unreadable at 200 DPI
- Some code reference numbers may have minor transcription errors
- Could be improved by zooming into specific regions for dense content
