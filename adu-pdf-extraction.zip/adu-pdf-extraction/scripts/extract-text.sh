#!/usr/bin/env bash
# extract-text.sh — OCR text from per-page PNGs using Tesseract
# Usage: extract-text.sh <input.pdf> <output-dir>
# Requires: tesseract, pdftoppm (from poppler) or pre-extracted PNGs
# Output: output-dir/pages-tesseract/page-01.txt, page-02.txt, etc.
#
# This script uses Tesseract OCR on page PNG images rather than pdftotext.
# Tesseract produces dramatically better results on construction PDFs because:
#   - It reads rasterized/scanned content (Title 24 CF1R reports)
#   - It handles CAD-rendered text that pdftotext cannot extract
#   - It reads through watermarks better than text-layer extraction
#   - It produces compact output without blank-line padding
#
# For best results, run extract-pages.sh first to generate PNGs, then
# run this script. If PNGs already exist, it will use them directly.

set -euo pipefail

if [ $# -lt 2 ]; then
  echo "Usage: $0 <input.pdf> <output-dir>"
  echo "  OCRs each page using Tesseract on page PNGs."
  echo "  Expects PNGs in output-dir/pages-png/ (run extract-pages.sh first)."
  exit 1
fi

INPUT_PDF="$1"
OUTPUT_DIR="$2"
PNG_DIR="${OUTPUT_DIR}/pages-png"
TEXT_DIR="${OUTPUT_DIR}/pages-tesseract"

if ! command -v tesseract &>/dev/null; then
  echo "Error: tesseract not found. Install: brew install tesseract"
  exit 1
fi

# Check if PNGs exist; if not, extract them
if [ ! -d "$PNG_DIR" ] || [ -z "$(ls "$PNG_DIR"/page-*.png 2>/dev/null)" ]; then
  echo "PNGs not found in $PNG_DIR. Extracting from PDF first..."
  SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
  bash "$SCRIPT_DIR/extract-pages.sh" "$INPUT_PDF" "$OUTPUT_DIR"
fi

mkdir -p "$TEXT_DIR"

PAGE_COUNT=$(ls "$PNG_DIR"/page-*.png 2>/dev/null | wc -l | tr -d ' ')

if [ "$PAGE_COUNT" -eq 0 ]; then
  echo "Error: No PNG files found in $PNG_DIR"
  exit 1
fi

echo "Running Tesseract OCR on $PAGE_COUNT page PNGs..."
echo "Output directory: $TEXT_DIR"

for png in "$PNG_DIR"/page-*.png; do
  basename=$(basename "$png" .png)
  OUTPUT_BASE="${TEXT_DIR}/${basename}"
  tesseract "$png" "$OUTPUT_BASE" 2>/dev/null || true
done

echo ""
echo "Done. OCR extraction summary:"
echo "---"
TOTAL_CHARS=0
for f in "$TEXT_DIR"/page-*.txt; do
  basename=$(basename "$f")
  lines=$(wc -l < "$f" | tr -d ' ')
  size=$(wc -c < "$f" | tr -d ' ')
  TOTAL_CHARS=$((TOTAL_CHARS + size))
  if [ "$size" -lt 500 ]; then
    quality="sparse"
  elif [ "$size" -gt 8000 ]; then
    quality="dense"
  else
    quality="moderate"
  fi
  printf "  %-14s %4s lines  %6s bytes  [%s]\n" "$basename" "$lines" "$size" "$quality"
done
echo "---"
echo "Total: $PAGE_COUNT pages, $TOTAL_CHARS bytes"
